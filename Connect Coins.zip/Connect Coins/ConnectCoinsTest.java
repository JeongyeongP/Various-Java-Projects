package PartB;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;

public class ConnectCoinsTest {

	@Test
    public void givenTestCase() {
        boolean[][] ccMatrix = {{true,  false, true,  true},
                                {true,  false, true,  false},
                                {true,  false, true,  false},
                                {false, true,  false, true},
                                {false, true,  false, true},
                                {true,  false, false, true}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
        // coordinate [2,1] and max 10
    }

    @Test
    public void testEmpty(){
        boolean[][] ccMatrix = {{true, false, true},
                                {false, true, false}};
        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }


    @Test
    public void testLarge() {
        boolean[][] ccMatrix = new boolean[1000][1000];
        for (int i =0; i<ccMatrix.length; i++) {
            for(int j=0; j<ccMatrix[0].length; j++) {
                ccMatrix[i][j]=false;
            }
        }

        ccMatrix[0][1] = true;
        ccMatrix[34][23] = true;
        ccMatrix[34][24] = true;

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());

    }


    @Test
    public void test2(){
        boolean[][] ccMatrix = {{false,  false, false, false},
                                {true,   true,  true,  false},
                                {false,  false, true,  false},
                                {false,  true,  false, false},
                                {false,  true,  false, false},
                                {false,  false, false, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test3(){
        boolean[][] ccMatrix = {{true, false},
                                {false, true}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test3x3(){
        boolean[][] ccMatrix = {{false, true, false},
                                {false, false, true},
                                {true, false, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test3flipped(){
        boolean[][] ccMatrix = {{false, true},
                                {true, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
        System.out.println(cc.maxConnCoins());
    }
//
    @Test
    public void test4(){
        boolean[][] ccMatrix = {{false,  false},
                                {false, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());

    }

    @Test
    public void test5(){
        boolean[][] ccMatrix = {{false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test6(){
        boolean[][] ccMatrix = {{true, false, true, false},
                                {false, false, false, true},
                                {false, true, false, false},
                                {false, false, true, false},
                                {false, true, false, false},
                                {false,  false, false, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test7(){
        boolean[][] ccMatrix = {{true, false, false, false},
                                {true, false, false, false},
                                {true, false, false, false},
                                {true, false, false, false},
                                {true, false, false, false},
                                {true, false, false, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }
//
    @Test
    public void test8(){
        boolean[][] ccMatrix = {{true,  false},
                                {false, true}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }
//
    @Test
    public void test9(){
        boolean[][] ccMatrix = {{true, true, true, true},
                                {true, false, false, true},
                                {true, false, false, true},
                                {true, true, true, true}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test10(){
        boolean[][] ccMatrix = {{true, false, true, false, true},
                {false, true, false, false, false},
                {false, false, true, false, false},
                {false, false, false, false, false},
                {false, false, true, false, true},
                {false, false, false, false, false}};
        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test11() {
        boolean[][] ccMatrix = {{false,  false, true, false, true},
                                {false, true, false, false, false},
                                {false, true, true, false, true},
                                {false, true, false, false, false},
                                {true, false, false, true, false}};
        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test12() {
        boolean[][] ccMatrix = {{true, false, true, false},
                                {true, false, true, false},
                                {true, false, true, false},
                                {true, false, true, false}};
        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }


    @Test
    public void testTrue(){
        boolean[][] ccMatrix = new boolean[1000][1000];
        for (int i =0; i<ccMatrix.length; i++) {
            for(int j=0; j<ccMatrix[0].length; j++) {
                ccMatrix[i][j]=true;
            }
        }
        ccMatrix[300][200] = false;
        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }

    @Test
    public void test1True(){
        boolean[][] ccMatrix = {{false, false, false, false},
                                {false, true, false, false},
                                {false, false, false, false},
                                {false, false, false, false}};

        ConnectCoins cc = new ConnectCoins(ccMatrix);
        System.out.println(cc.maxConnCoins());
    }
	//@Test
//	public void testLarge() {
//	    boolean[][] ccMatrix = new boolean[1000][1000];
//	    for (int i =0; i<ccMatrix.length; i++) {
//	        for(int j=0; j<ccMatrix[0].length; j++) {
//	            ccMatrix[i][j]=false;
//	        }
//	    }
//
//	    ccMatrix[0][1] = true;
//	    ccMatrix[34][23] = true;
//	    ccMatrix[34][24] = true;
//	    ccMatrix[313][33] = true;
//
//	    ConnectCoins cc = new ConnectCoins(ccMatrix);
//	    System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//	    System.out.println(cc.maxConnCoins());
//
//	}
	//@Test
//	public void test12() {
//	    boolean[][] ccMatrix = {{true, false, true, false},
//	                            {true, false, true, false},
//	                            {true, false, true, false},
//	                            {true, false, true, false}};
//	    ConnectCoins cc = new ConnectCoins(ccMatrix);
//	    System.out.println(cc.maxConnCoins());
//	    System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//	}
//	
//	@Test
//    public void givenTestCase3() {
//     System.out.println("givenTestCase3");
//        boolean[][] ccMatrix = new boolean[4][4];
//        for(int i = 0; i < 4; i++){
//            for(int j = 0; j < 4; j++){
//                if((i+j) % 2 == 0){
//                    ccMatrix[i][j] = true;
//                }
//                else{
//                    ccMatrix[i][j] = false;
//                }
//            }
//        }
//        
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        int scores = 5;
//        int[] location = new int[2];
//        location[0] = 1;
//        location[1] = 2;
//        assertArrayEquals(location, cc.placeMaxConnCoins());
//        assertEquals(scores, cc.maxConnCoins());
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println();
//    }
	
	//@Test
//    public void givenTestCase() {
//        boolean[][] ccMatrix = {{true,  false, true,  true},
//                                {true,  false, true,  false},
//                                {true,  false, true,  false},
//                                {false, true,  false, true},
//                                {false, true,  false, true},
//                                {true,  false, false, true}};
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        int scores = 10;
//        //[2,1]
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        assertEquals(scores, cc.maxConnCoins());
//    }
    
//    @Test
//    public void TestCase1() {
//        boolean[][] ccMatrix = {{false,  false, false,  true},
//                                {false,  false, false,  false},
//                                {false, false, false, false}};
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        int scores = 2;
//        //[0,2]
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        assertEquals(scores, cc.maxConnCoins());
//    }
//    
//    @Test
//    public void TestCase2() {
//    	boolean[][] ccMatrix = {{true, true, true, true},
//    							{true, false, false, true},
//    							{true, false, false, true},
//    							{true, true, true, true,}};
//    	ConnectCoins cc = new ConnectCoins(ccMatrix);
//        int scores = 13;
//        //[1,1]
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        assertEquals(scores, cc.maxConnCoins()); 	
//    	
//    }
//    @Test
//    public void TestCase3() {
//        boolean[][] ccMatrix = {{false,  false, true, false, true},
//                                {false, true, false, false, false},
//                                {false, true, true, false, true},
//                                {false, true, false, false, false},
//                                {true, false, false, true, false},};
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        int scores = 6;
//        assertEquals(scores, cc.maxConnCoins());
//    }
//    
//    @Test
//    public void TestCase4(){
//        boolean[][] ccMatrix = {{false,  false, false, false},
//                                {true,   true,  true,  false},
//                                {false,  false, true,  false},
//                                {false,  true,  false, false},
//                                {false,  true,  false, false},
//                                {false,  false, false, false}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//
//    @Test
//    public void TestCase5(){
//        boolean[][] ccMatrix = {{true,  false},
//                                {false, true}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//
//    @Test
//    public void TestCase6(){
//        boolean[][] ccMatrix = {{false,  false},
//                                {false, false}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//
//    }
//
//    @Test
//    public void TestCase7(){
//        boolean[][] ccMatrix = {{false}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//
//    @Test
//    public void TestCase8(){
//        boolean[][] ccMatrix = {{true, false, true, false},
//                                {false, false, false, true},
//                                {false, true, false, false},
//                                {false, false, true, false},
//                                {false, true, false, false},
//                                {false,  false, false, false}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//
//    @Test
//    public void TestCase9(){
//        boolean[][] ccMatrix = {{true, false, false, false},
//                                {true, false, false, false},
//                                {true, false, false, false},
//                                {true, false, false, false},
//                                {true, false, false, false},
//                                {true, false, false, false}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//
//    @Test
//    public void TestCase10(){
//        boolean[][] ccMatrix = {{true,  false},
//                                {false, true}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//
//    @Test
//    public void TestCase11(){
//        boolean[][] ccMatrix = {{true, true, true, true},
//                                {true, false, false, true},
//                                {true, false, false, true},
//                                {true, true, true, true}};
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//
//        System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    }
//    
//    @Test
//    public void testLarge1() {
//    	boolean[][] ccMatrix = new boolean[50][50];
//    	for (int i =0; i<50; i++) {
//    		for(int j=0; j<50; j++) {
//    			ccMatrix[i][j]=false;
//    		}
//    	}
//    	
//    	ConnectCoins cc = new ConnectCoins(ccMatrix);
//    	System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    	
//    }
//  @Test
//  public void TestCase12(){
//      boolean[][] ccMatrix = {{false, false, false, false},
//                              {false, true, false, false},
//                              {false, false, false, false},
//                              {false, false, false, false}};
//
//      ConnectCoins cc = new ConnectCoins(ccMatrix);
//      //[0,1]
//      System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//      System.out.println(cc.maxConnCoins());
//  }
//  @Test
//  public void TestCase13(){
//      boolean[][] ccMatrix = {{true,  false},
//                              {false, true}};
//
//      ConnectCoins cc = new ConnectCoins(ccMatrix);
//      System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//      System.out.println(cc.maxConnCoins());
//  }
//    @Test
//    public void testLarge2() {
//    	boolean[][] ccMatrix = new boolean[1000][1000];
//    	for (int i =0; i<1000; i++) {
//    		for(int j=0; j<1000; j++) {
//    			ccMatrix[i][j]=false;
//    		}
//    	}
//    	
//    	
//    	ConnectCoins cc = new ConnectCoins(ccMatrix);
//    	System.out.println(Arrays.toString(cc.placeMaxConnCoins()));
//        System.out.println(cc.maxConnCoins());
//    	
//    }
//    @Test
//    public void testLarge3() {
//        boolean[][] ccMatrix = new boolean[1000][1000];
//        for (int i =0; i<ccMatrix.length; i++) {
//            for(int j=0; j<ccMatrix[0].length; j++) {
//                ccMatrix[i][j]=false;
//            }
//        }
//
//        ccMatrix[0][1] = true;
//        ccMatrix[34][23] = true;
//        ccMatrix[34][24] = true;
//        ccMatrix[313][33] = true;
//
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        System.out.println(cc.maxConnCoins());
//
//    }
//    
//    @Test
//    public void TestCase14() {
//        long start = System.currentTimeMillis();
//        boolean[][] ccMatrix = {{true,  false, true,  true},
//                {true, false, true, false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true, true, true, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true},
//                {true,  false, true,  false},
//                {true,  false, true,  false},
//                {false, true,  false, true},
//                {false, true,  false, true},
//                {true,  false, false, true}};
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        int scores = 19;
//        assertEquals(scores, cc.maxConnCoins());
//        long end = System.currentTimeMillis();
//        System.out.println("Execute time: " + (end - start)+"ms");
//    }
//    @Test
//    public void testTrue(){
//        boolean[][] ccMatrix = new boolean[1000][1000];
//        for (int i =0; i<ccMatrix.length; i++) {
//            for(int j=0; j<ccMatrix[0].length; j++) {
//                ccMatrix[i][j]=true;
//            }
//        }
//        ccMatrix[300][200] = false;
//        ConnectCoins cc = new ConnectCoins(ccMatrix);
//        System.out.println(cc.maxConnCoins());
//    }

}
