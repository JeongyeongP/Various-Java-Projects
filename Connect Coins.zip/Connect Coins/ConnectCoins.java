package PartB;

import java.util.ArrayList;       // optional

import PartA.UnionFind;

public class ConnectCoins {

    private final UnionFind uf1;
    private final UnionFind uf2;  // optional
    private final boolean[][] ccMatrix;   // optional
    private final int row;        // optional
    private final int column;     // optional


    /*
     *****  DO NOT CHANGE ANY INSTANCE VARIABLES ABOVE *****
     *****  DO NOT ADD ANY INSTANCE VARIABLES **************
     *****  DO NOT ADD ANY LIBRARIES ******** **************
     *****  VIOLATION = 0 MARKS IN PART B ******************
     */

    /*
     ***** HELPER METHODS START *****
     */

    // Add your own helper methods here
    // INCLUDE your helper methods in your submission !
    
    //In order to manage 2D array for UnionFind
    
    private void connect(boolean[][] ccMatrix, UnionFind uf) {
    	
    	for (int i=0; i<row; i++) {
    		for(int j=0; j<column; j++) {
    			if(ccMatrix[i][j]==true) {
    				//check right
    				if(j!=column-1) {
    					if(ccMatrix[i][j+1]==true && j!=column-1) {
    						int p = i*column+(j+1);
        					int q = i*column+j;
        					uf.union(p,q);
        				}
    				}	
    				//check down
    				if(i!=row-1) {
    					if(ccMatrix[i+1][j]==true && i!=row-1) {
        					int p = (i+1)*column+j;
        					int q = i*column+j;
        					uf.union(p, q);
        				}
    				}
    			}
    		}	
    	}
    }
    
    
    private boolean isFalse(int i, int j) {
    	
    	//check except for corners
    	//middle part of matrix
    	if((j!=column-1 && ccMatrix[i][j+1]==false) && (i!=row-1 && ccMatrix[i+1][j]==false) && (j!=0 && ccMatrix[i][j-1]==false) && (i!=0 && ccMatrix[i-1][j]==false)) {
    		return true;
    	}
    	//first row
    	else if(i==0 && j!=0 && j!=column-1 && ccMatrix[i][j+1]==false && ccMatrix[i][j-1]==false && ccMatrix[i+1][j]==false) {
    		return true;
    	}
    	//last row
    	else if(i==row-1 && j!=0 && j!=column-1 && ccMatrix[i][j+1]==false && ccMatrix[i][j-1]==false && ccMatrix[i-1][j]==false) {
    		return true;
    	}
    	//first column
    	else if(j==0 && i!=0 && i!=row-1 && ccMatrix[i+1][j]==false && i!=0 && ccMatrix[i-1][j]==false && ccMatrix[i][j+1]==false) {
    		return true;
    	}
    	//last column
    	else if(j==column-1 && i!=0 && i!=row-1 && ccMatrix[i+1][j]==false && i!=0 && ccMatrix[i-1][j]==false && ccMatrix[i][j-1]==false) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
     

    /*
     ***** HELPER METHODS END *****
     */


    // COURSEWORK 3 PART B.1 Connect Coin CONSTRUCTOR

    /**
     * Initializes the instance variable including a UnionFind data structure.
     * @param ccMatrix is s a 2-D boolean array of true (T) and false (F) values
     *                 to represent the 2-D space where A T in a coordinate indicates that there is a coin
     *                 at that position in the 2-D space, while an F indicates an empty space
     */
    public ConnectCoins(boolean[][] ccMatrix) {
    
        uf1 = new UnionFind(ccMatrix.length*ccMatrix[0].length);
        uf2 = null;
        this.ccMatrix = ccMatrix;
        row = ccMatrix.length;
        column = ccMatrix[0].length;
        
    }

    // COURSEWORK 3 PART B.2 Connect Coins PLACE MAX CONNECTED COINS

    /**
     * @return a 2-element integer array that represents the coordinate in [row, column],
     * so that a coin that is placed in that coordinate will give the maximum number of newly connected coins.
     * If there are multiple possible such placements, return the left-and-topmost coordinate.
     */

    public int[] placeMaxConnCoins() {
    	
    	//[row, column]
    	int[] arr = new int[2];
    	for (int i = 0; i<2; i++) {
    		arr[i]=0;
    	}
    	int maxSize = 0;
    	connect(ccMatrix,uf1);
    	
    	for (int i=0; i<row; i++) {
    		for(int j=0; j<column; j++) {
    			
    			if(ccMatrix[i][j]==false && !isFalse(i,j)) {
    				UnionFind ufTrack = new UnionFind(row*column);
        			connect(ccMatrix,ufTrack);
    		
    				if(j!=0 && ccMatrix[i][j-1]==true) {//left side of false
    					int p = i*column+j;
    					int q = i*column+(j-1); //parent
    					ufTrack.union(p, q);
    					
    					if(maxSize<ufTrack.sizeOf(q)) {
    						maxSize=ufTrack.sizeOf(q);
    						arr[0]=i;
    						arr[1]=j;
    					}
    				}
    				if(j!=column-1 && ccMatrix[i][j+1]==true) {//right side of false
    					int p = i*column+j;
    					int q = i*column+(j+1); //parent
    					ufTrack.union(p, q);
 
    					if(maxSize<ufTrack.sizeOf(q)) {
    						maxSize=ufTrack.sizeOf(q);
    						arr[0]=i;
    						arr[1]=j;
    					}	
    				}
    				if(i!=0 && ccMatrix[i-1][j]==true) {//upper of false
    					int p = i*column+j;
    					int q = (i-1)*column+j;
    					ufTrack.union(p, q);
    					
    					if(maxSize<ufTrack.sizeOf(q)) {
    						maxSize=ufTrack.sizeOf(q);
    						arr[0]=i;
    						arr[1]=j;
    					}
    				}
    				if(i!=row-1 && ccMatrix[i+1][j]==true) {//lower of false
    					int p = i*column+j;
    					int q = (i+1)*column+j;
    					ufTrack.union(p, q);
    					
    					if(maxSize<ufTrack.sizeOf(q)) {
    						maxSize=ufTrack.sizeOf(q);
    						arr[0]=i;
    						arr[1]=j;
    					}
    				}
    			}
    			
    		}
    	}
    	
    	return arr;
    
    }


    // COURSEWORK 3 PART B.3 Connect Coins MAX CONNECTED COINS

    /**
     * @return the maximum number of newly connected coins after placing a new coin.
     */

    public int maxConnCoins() {
    	int[] position = new int[2];
    	position = placeMaxConnCoins();
    	
    	
    	int id = position[0]*column+position[1];
    	int max_row = position[0];
    	int max_column = position[1];
    	//union and get size
    	if(max_row!=0 && ccMatrix[max_row-1][max_column]==true) {//up
    		int p=id;
    		int q=(max_row-1)*column+max_column;
    		uf1.union(p,q);
    	}
    	if(max_row!=row-1 && ccMatrix[max_row+1][max_column]==true) {//down
    		int p=id;
    		int q=(max_row+1)*column+max_column;
    		uf1.union(p,q);
    	}
    	if(max_column!=0 && ccMatrix[max_row][max_column-1]==true) {//left
    		int p=id;
    		int q=(max_row)*column+(max_column-1);
    		uf1.union(p,q);
    	}
    	if(max_column!=column-1 && ccMatrix[max_row][max_column+1]==true) {//right
    		int p=id;
    		int q=(max_row)*column+(max_column+1);
    		uf1.union(p,q);
    	}
    	return uf1.sizeOf(id);

    
       
    }
    
    public static void main(String[] args) {
//    	 boolean[][] ccMatrix = {{true,  false, true,  true},
//                 {true,  false, true,  false},
//                 {true,  false, true,  false},
//                 {false, true,  false, true},
//                 {false, true,  false, true},
//                 {true,  false, false, true}};
//    	 ConnectCoins cc = new ConnectCoins(ccMatrix);
    	boolean[][] ccMatrix = {{false,  false, true, false, true},
                {false, true, false, false, false},
                {false, true, true, false, true},
                {false, true, false, false, false},
                {true, false, false, true, false},};
    	ConnectCoins cc = new ConnectCoins(ccMatrix);
    	 cc.placeMaxConnCoins();
    
    
   }

}