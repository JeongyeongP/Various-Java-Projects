package PartA;

import org.junit.Test;

import static org.junit.Assert.*;

public class UnionFindTest {

    @Test
    public void testDS_1() {
        UnionFind uf = new UnionFind(4);
        uf.union(1, 0);
        assertTrue(uf.isSameGroup(1, 0));
        assertEquals(2, uf.sizeOf(1));
        assertEquals(0, uf.parent(1));
        assertEquals(-2, uf.parent(0));
        uf.union(3, 2);
        assertFalse(uf.isSameGroup(3, 1));
        uf.union(3, 1);
        assertEquals(2, uf.parent(3));
        assertTrue(uf.isSameGroup(3, 1));
        assertEquals(0, uf.parent(3));
    }
    
    @Test
    public void testDS_2() {
        UnionFind uf = new UnionFind(4);
        uf.union(1, 0);
        assertTrue(uf.isSameGroup(1, 0));
        assertEquals(2, uf.sizeOf(1));
        assertEquals(0, uf.parent(1));
        assertEquals(-2, uf.parent(0));
        uf.union(3, 2);
        assertFalse(uf.isSameGroup(3, 1));
        uf.union(3, 1);
        assertEquals(2, uf.parent(3));
        assertTrue(uf.isSameGroup(3, 1));
        assertEquals(0, uf.parent(3));
    }
    
    @Test
    public void test3() {
    	UnionFind uf = new UnionFind(19);
    	uf.printParent();
    	System.out.println(uf.sizeOf(16));
    	System.out.println(uf.isSameGroup(16, 0));
    	for(int i=1; i<=15; i+=2) {
    	    uf.union(i+1, i);
    	}
    	uf.printParent();
    	System.out.println(uf.isSameGroup(0, 16));
    	System.out.println(uf.isSameGroup(15, 16));
    	System.out.println(uf.sizeOf(0));
    	System.out.println(uf.sizeOf(15));
    	System.out.println(uf.sizeOf(16));
    	for(int i=1; i<=15; i+=2) {
    		System.out.println("For loop i : "+i);
    	    uf.union(i+1, i);
    	}
    	uf.printParent();
    	System.out.println("Done printing");
    	
    	uf.union(1, 3);
    	System.out.println("done union");
    	uf.union(5, 8);
    	uf.printParent();
    	System.out.println("Checking");
    	
    	uf.union(10, 11);
    	uf.union(14, 16);
    	
    	uf.printParent();
    	System.out.println(uf.sizeOf(6));
    	System.out.println(uf.sizeOf(13));
    	System.out.println(uf.isSameGroup(1, 8));
    	System.out.println(uf.isSameGroup(11, 15));
    	uf.union(2, 5);
    	System.out.println("After union 2 and 5");
    	uf.printParent(); 
    }
    	
    
  
    @Test
    public void testWeightedSize() {
        UnionFind uf = new UnionFind(19);
        uf.printParent();
        System.out.println(uf.sizeOf(16));
        System.out.println(uf.isSameGroup(16, 0));
        for (int i = 1; i <= 15; i += 2) {
            uf.union(i + 1, i);
        }
        uf.printParent();
        System.out.println(uf.isSameGroup(0, 16));
        System.out.println(uf.isSameGroup(15, 16));
        System.out.println(uf.sizeOf(0));
        System.out.println(uf.sizeOf(15));
        System.out.println(uf.sizeOf(16));
        for (int i = 1; i <= 15; i += 2) {
            uf.union(i + 1, i);
        }
        uf.printParent();
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateTest_1() {
        UnionFind uf = new UnionFind(5);
        uf.validate(10);
    }
    
    @Test
    public void test4() {
    	UnionFind uf = new UnionFind(19);
    	uf.printParent();
    	System.out.println(uf.sizeOf(16));
    	System.out.println(uf.isSameGroup(16, 0));
    	for (int i = 1; i <= 15; i += 2) {
    	    uf.union(i + 1, i);
    	}
    	uf.printParent();
    	System.out.println(uf.isSameGroup(0, 16));
    	System.out.println(uf.isSameGroup(15, 16));
    	System.out.println(uf.sizeOf(0));
    	System.out.println(uf.sizeOf(15));
    	System.out.println(uf.sizeOf(16));
    	for(int i=1; i<=15; i+=2) {
    	    uf.union(i+1, i);
    	}
    	uf.printParent();
    	uf.union(1, 3);
    	uf.union(5, 8);
    	uf.union(10, 11);
    	uf.union(14, 16);
    	uf.printParent();
    	System.out.println(uf.sizeOf(6));
    }



}
