package PartA;

public class UnionFind {

    private int[] parent;

    /*
     * Returns the parent of element p.
     * If p is the root of a tree, returns the negative size
     * of the tree for which p is the root.
     */
    public int parent(int p) {
        return parent[p];
    }

    /* Prints the parents of the elements, separated by a space */
    public void printParent() {
        for (int element : parent) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    /*
     *****  DO NOT CHANGE ANY INSTANCE VARIABLES ABOVE *****
     *****  DO NOT ADD ANY INSTANCE VARIABLES **************
     *****  DO NOT ADD ANY LIBRARIES ******** **************
     *****  VIOLATION = 0 MARKS IN PART A ******************
     */


    /*
     ***** HELPER METHODS START *****
     */
    


    /*
     ***** HELPER METHODS END *****
     */


    // COURSEWORK 3 PART A.1 Union Find CONSTRUCTOR

    /**
     * Creates a Union Find data structure with N elements,
     * 0 through N-1.
     * Initially, each element is in its own set.
     * @param N the number of elements
     */
    public UnionFind(int N) {
    	parent = new int[N];
  
        for (int i = 0; i<N; i++) {
     	   parent[i] = -1;
        }
    }


    // COURSEWORK 3 PART A.2 Union Find VALIDATE

    /**
     * Validates that p is a valid element/index.
     * @param p is an element
     * @throws IllegalArgumentException if p is not a valid index.
     */
    public void validate(int p) {
    	if(p<0 || p>= parent.length) {
    		throw new IllegalArgumentException();
    	}
    }


    // COURSEWORK 3 PART A.3 Union Find SIZE OF

    /**
     * Returns the size of the set element p belongs to.
     * @param p is a valid element
     * @return the size of the set containing p
     */
    public int sizeOf(int p) {

    	int size = 0;
        int root = p;
        
        //finding parent
        while (parent(root)>-1) {
    		root = parent(root);
    	}
        
        size = -parent(root);
        return size;

    }


    // COURSEWORK 3 PART A.4 Union Find FIND

    /**
     * Returns the group identity number which is the root of the tree element p belongs to.
     * Path-compression is now employed allowing for fast search-time.
     * @param p is a valid element
     * @return the root of the group p belongs to.
     */
    public int find(int p) {

    	validate(p);
        if (parent[p] < 0) {
    		return p;
    	}
    	// Path Compression
    	return parent[p] = find(parent[p]);
    }


    // Note that now, the method isSameGroup(int p, int q) is given
    // Using find above, it simply checks whether find(p) is the same as find(q)

    /**
     * Returns true iff elements p is in the same group as q.
     * @param p is an element
     * @param q is the other element
     * @return true if p and q are in the same group
     *         false otherwise
     * @throws IllegalArgumentException if p or q is not a valid index.
     */
    public boolean isSameGroup(int p, int q) {
        validate(p);
        validate(q);
        return find(p) == find(q);
    }


    // COURSEWORK 3 PART A.5 Union Find CONNECT

    /**
     * Combines two elements p and q together,
     * by combining the sets containing them.
     * @param p is an element
     * @param q is the other element
     * @throws IllegalArgumentException if p or q is not a valid index.
     */
    public void union(int p, int q) {
    	int pRoot = find(p); 
    	int qRoot = find(q);
    	
    	if (!isSameGroup(p, q)) {
    		if(sizeOf(pRoot)>sizeOf(qRoot)) {
    			parent[pRoot]=parent[pRoot]+parent[qRoot];
    			parent[qRoot]=pRoot;
    		}
    		else if(sizeOf(pRoot)<=sizeOf(qRoot)) {
    			parent[qRoot]=parent[qRoot]+parent[pRoot];
    			parent[pRoot]=qRoot;
    		}
    	}
    }


    public static void main(String[] args) {
//        UnionFind uf1 = new UnionFind(4);
//        System.out.println("Created");
//        uf1.union(1, 0);
//        uf1.union(3, 2);
//        uf1.union(3, 1);
//        uf1.printParent();
//        
//        UnionFind uf = new UnionFind(4);
//        uf.printParent();
//        System.out.println("Created");
//        uf.union(1, 0);
//        System.out.println("done");
//        uf.isSameGroup(1, 0);
//        uf.sizeOf(1);
//        uf.parent(1);
//        uf.parent(0);
//        uf.union(3, 2);
//        System.out.println("done");
//        uf.isSameGroup(3, 1);
//        uf.union(3, 1);
//        System.out.println("done");
//        uf.parent(3);
//        uf.isSameGroup(3, 1);
//        uf.parent(3);
//        System.out.println("done");
    	UnionFind uf = new UnionFind(6);
    	uf.union(1, 0);
    	uf.union(3, 2);
    	uf.union(3, 1);
    	uf.union(5,4);
    	uf.union(4,3);
    	uf.printParent();

    }
}
